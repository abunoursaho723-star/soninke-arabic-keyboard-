package com.soninke.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView

class SoninkeInputMethodService : InputMethodService() {
    private val rows = listOf(
        listOf("ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"),
        listOf("ش","س","ي","ب","ل","ا","ت","ن","م","ك","ط"),
        listOf("ئ","ء","ؤ","ر","لا","ى","ة","و","ز","ظ"),
        listOf("پ","چ","ڠ","ݝ","ݧ","ۑ","ڭ","َ","ُ","ِ","ْ"),
        listOf("ّ","ً","ٌ","ٍ","ٰ","ٓ","ٔ","ٖ","ٗ","٘"),
        listOf("١","٢","٣","٤","٥","٦","٧","٨","٩","٠"),
        listOf("،","؛","؟",".","-","!","⌫","مسافة","↵")
    )

    override fun onCreateInputView(): View {
        val scroller = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 6)
            setBackgroundColor(Color.rgb(235, 238, 242))
        }
        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { key ->
                val button = Button(this).apply {
                    text = key
                    textSize = if (key.length > 1) 13f else 21f
                    typeface = Typeface.DEFAULT
                    isAllCaps = false
                    setTextColor(Color.rgb(25, 31, 39))
                    setPadding(0, 0, 0, 0)
                    minWidth = 0
                    minimumWidth = 0
                    minHeight = 0
                    minimumHeight = 0
                    setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE))
                    setOnClickListener { handleKey(key) }
                }
                val params = LinearLayout.LayoutParams(0, 48, if (key == "مسافة") 3f else if (key == "⌫" || key == "↵") 1.4f else 1f)
                params.setMargins(2, 2, 2, 2)
                line.addView(button, params)
            }
            container.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        scroller.addView(container)
        return scroller
    }

    private fun handleKey(key: String) {
        val ic: InputConnection = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "مسافة" -> ic.commitText(" ", 1)
            "↵" -> ic.commitText("\n", 1)
            "لا" -> ic.commitText("لا", 1)
            else -> ic.commitText(key, 1)
        }
    }
}
